// frontend/src/pages/Playlists/PlaylistPage.tsx
import React, { useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import usePlaylistStore from "../../stores/usePlaylistStore";
import usePlayerStore from "../../stores/usePlayerStore"; // Assuming you have a player store
import useAuthStore from "../../stores/useAuthStore"; // Assuming you have an auth store
import { Button } from "../../components/ui/button";
import { ScrollArea } from "../../components/ui/scroll-area";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../../components/ui/table";
import { Clock, Play, Heart, PlusCircle, Trash2, Edit } from "lucide-react";
import { PlaylistSkeleton } from "../../components/ui/skeletons/PlaylistSkeleton"; // Assuming you have a PlaylistSkeleton
import { useToast } from "../../components/ui/use-toast";
import { EditPlaylistDialog } from "./EditPlaylistDialog"; // We'll create this next
import { AddSongToPlaylistDialog } from "./AddSongToPlaylistDialog"; // We'll create this next
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "../../components/ui/dropdown-menu";

export const PlaylistPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { toast } = useToast();

  const {
    currentPlaylist,
    loading,
    error,
    fetchPlaylistById,
    deletePlaylist,
    likePlaylist,
    unlikePlaylist,
    removeSongFromPlaylist,
    clearCurrentPlaylist,
  } = usePlaylistStore();
  const { setCurrentSong, setIsPlaying, setQueue } = usePlayerStore();
  const { user } = useAuthStore();

  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isAddSongDialogOpen, setIsAddSongDialogOpen] = useState(false);

  useEffect(() => {
    if (id) {
      fetchPlaylistById(id);
    }
    return () => {
      clearCurrentPlaylist(); // Clear playlist data when unmounting
    };
  }, [id, fetchPlaylistById, clearCurrentPlaylist]);

  const handlePlayPlaylist = () => {
    if (currentPlaylist && currentPlaylist.songs.length > 0) {
      setQueue(currentPlaylist.songs);
      setCurrentSong(currentPlaylist.songs[0]);
      setIsPlaying(true);
    } else {
      toast({
        title: "No songs",
        description: "This playlist has no songs to play.",
        variant: "default",
      });
    }
  };

  const handlePlaySong = (song: Song) => {
    if (currentPlaylist) {
      const songIndex = currentPlaylist.songs.findIndex(
        (s) => s._id === song._id
      );
      if (songIndex !== -1) {
        const remainingSongs = currentPlaylist.songs.slice(songIndex);
        setQueue(remainingSongs);
        setCurrentSong(song);
        setIsPlaying(true);
      }
    }
  };

  const handleDeletePlaylist = async () => {
    if (currentPlaylist && id) {
      if (window.confirm("Are you sure you want to delete this playlist?")) {
        const success = await deletePlaylist(id);
        if (success) {
          toast({ title: "Success", description: "Playlist deleted." });
          navigate("/library"); // Redirect to library after deletion
        } else {
          toast({
            title: "Error",
            description: "Failed to delete playlist.",
            variant: "destructive",
          });
        }
      }
    }
  };

  const handleToggleLike = async () => {
    if (!currentPlaylist || !user) return;

    const isLiked = currentPlaylist.likes.includes(user._id);
    let success: boolean;
    if (isLiked) {
      success = await unlikePlaylist(currentPlaylist._id);
      if (success) {
        toast({ title: "Success", description: "Playlist unliked." });
      } else {
        toast({
          title: "Error",
          description: "Failed to unlike playlist.",
          variant: "destructive",
        });
      }
    } else {
      success = await likePlaylist(currentPlaylist._id);
      if (success) {
        toast({ title: "Success", description: "Playlist liked." });
      } else {
        toast({
          title: "Error",
          description: "Failed to like playlist.",
          variant: "destructive",
        });
      }
    }
    // Re-fetch playlist to update like status if the store update is not immediate (though it should be)
    if (success && id) {
      fetchPlaylistById(id);
    }
  };

  const handleRemoveSong = async (songId: string) => {
    if (currentPlaylist && id) {
      if (
        window.confirm(
          "Are you sure you want to remove this song from the playlist?"
        )
      ) {
        const success = await removeSongFromPlaylist(id, songId);
        if (success) {
          toast({
            title: "Success",
            description: "Song removed from playlist.",
          });
        } else {
          toast({
            title: "Error",
            description: "Failed to remove song.",
            variant: "destructive",
          });
        }
      }
    }
  };

  if (loading && !currentPlaylist) {
    return <PlaylistSkeleton />;
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-full text-red-500">
        <p>Error: {error}</p>
        <Button onClick={() => navigate("/library")}>Go to Library</Button>
      </div>
    );
  }

  if (!currentPlaylist) {
    return (
      <div className="flex items-center justify-center h-full text-white-500">
        <p>Playlist not found.</p>
        <Button onClick={() => navigate("/library")}>Go to Library</Button>
      </div>
    );
  }

  const isOwner = user && currentPlaylist.owner._id === user._id;
  const isPlaylistLiked = user && currentPlaylist.likes.includes(user._id);

  return (
    <ScrollArea className="h-full">
      <div className="p-8 pb-24">
        <div className="flex flex-col md:flex-row items-center md:items-end gap-6 mb-8 bg-gradient-to-b from-purple-800/20 to-transparent p-6 rounded-lg">
          <img
            src={currentPlaylist.imageUrl || "/default-playlist-cover.png"} // Use a default image if none provided
            alt={currentPlaylist.title}
            className="w-48 h-48 md:w-64 md:h-64 object-cover rounded-md shadow-lg"
          />
          <div className="flex flex-col text-center md:text-left gap-2">
            <p className="text-sm font-semibold text-gray-300">Playlist</p>
            <h1 className="text-4xl md:text-6xl font-bold text-white leading-tight">
              {currentPlaylist.title}
            </h1>
            {currentPlaylist.description && (
              <p className="text-md text-gray-400 mt-2">
                {currentPlaylist.description}
              </p>
            )}
            <div className="text-sm text-gray-400 mt-2">
              <span>By {currentPlaylist.owner.fullName}</span>
              <span className="mx-2">•</span>
              <span>{currentPlaylist.songs.length} songs</span>
              <span className="mx-2">•</span>
              <span>{currentPlaylist.likes.length} likes</span>
              <span className="mx-2">•</span>
              <span>{currentPlaylist.isPublic ? "Public" : "Private"}</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-4 mb-8">
          <Button
            size="lg"
            className="rounded-full bg-green-500 hover:bg-green-600 text-black shadow-lg"
            onClick={handlePlayPlaylist}
          >
            <Play className="h-6 w-6 fill-black" />
          </Button>

          <Button
            variant="ghost"
            size="icon"
            className="rounded-full text-white hover:bg-white/20"
            onClick={handleToggleLike}
          >
            <Heart
              className={`h-7 w-7 ${
                isPlaylistLiked ? "fill-red-500 text-red-500" : "text-gray-400"
              }`}
            />
          </Button>

          {isOwner && (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  variant="ghost"
                  size="icon"
                  className="rounded-full text-white hover:bg-white/20"
                >
                  <PlusCircle className="h-7 w-7 text-gray-400" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56 bg-zinc-800 text-white border-zinc-700">
                <DropdownMenuItem
                  onClick={() => setIsAddSongDialogOpen(true)}
                  className="hover:bg-zinc-700 cursor-pointer"
                >
                  <PlusCircle className="mr-2 h-4 w-4" /> Add Song
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={() => setIsEditDialogOpen(true)}
                  className="hover:bg-zinc-700 cursor-pointer"
                >
                  <Edit className="mr-2 h-4 w-4" /> Edit Playlist
                </DropdownMenuItem>
                <DropdownMenuItem
                  onClick={handleDeletePlaylist}
                  className="hover:bg-zinc-700 cursor-pointer text-red-400"
                >
                  <Trash2 className="mr-2 h-4 w-4" /> Delete Playlist
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          )}
        </div>

        <div className="mt-8">
          <Table>
            <TableHeader>
              <TableRow className="border-b border-zinc-700">
                <TableHead className="w-[50px] text-gray-400">#</TableHead>
                <TableHead className="text-gray-400">Title</TableHead>
                <TableHead className="text-gray-400">Album</TableHead>
                <TableHead className="text-gray-400">
                  <Clock className="h-4 w-4" />
                </TableHead>
                {isOwner && (
                  <TableHead className="text-gray-400">Actions</TableHead>
                )}
              </TableRow>
            </TableHeader>
            <TableBody>
              {currentPlaylist.songs.length === 0 ? (
                <TableRow>
                  <TableCell
                    colSpan={isOwner ? 5 : 4}
                    className="text-center py-8 text-gray-500"
                  >
                    No songs in this playlist.
                  </TableCell>
                </TableRow>
              ) : (
                currentPlaylist.songs.map((song, index) => (
                  <TableRow
                    key={song._id}
                    className="group hover:bg-zinc-800/50 transition-colors cursor-pointer"
                    onDoubleClick={() => handlePlaySong(song)}
                  >
                    <TableCell className="font-medium text-gray-400">
                      {index + 1}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-4">
                        <img
                          src={song.imageUrl}
                          alt={song.title}
                          className="h-10 w-10 object-cover rounded"
                        />
                        <div>
                          <div className="font-semibold text-white">
                            {song.title}
                          </div>
                          <div className="text-sm text-gray-400">
                            {song.artist}
                          </div>
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="text-gray-400">
                      {song.albumId ? "Album Name Placeholder" : "Single"}
                    </TableCell>{" "}
                    {/* TODO: Fetch album name if albumId exists */}
                    <TableCell className="text-gray-400">
                      {Math.floor(song.duration / 60)}:
                      {("0" + Math.floor(song.duration % 60)).slice(-2)}
                    </TableCell>
                    {isOwner && (
                      <TableCell>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-gray-400 hover:text-red-500"
                          onClick={() => handleRemoveSong(song._id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </TableCell>
                    )}
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      {isOwner && currentPlaylist && (
        <>
          <EditPlaylistDialog
            isOpen={isEditDialogOpen}
            onClose={() => setIsEditDialogOpen(false)}
            playlist={currentPlaylist}
          />
          <AddSongToPlaylistDialog
            isOpen={isAddSongDialogOpen}
            onClose={() => setIsAddSongDialogOpen(false)}
            playlistId={currentPlaylist._id}
          />
        </>
      )}
    </ScrollArea>
  );
};
