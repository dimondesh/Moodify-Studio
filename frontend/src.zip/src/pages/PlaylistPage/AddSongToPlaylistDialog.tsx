// frontend/src/pages/Playlists/AddSongToPlaylistDialog.tsx
import React, { useEffect, useState } from "react";
import { Button } from "../../components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "../../components/ui/dialog";
import { Input } from "../../components/ui/input";
import { ScrollArea } from "../../components/ui/scroll-area";
import usePlaylistStore from "../../stores/usePlaylistStore";
import { useMusicStore } from "../../stores/useMusicStore"; // Assuming a store to fetch all songs
import { useToast } from "../../components/ui/use-toast";
import { Check } from "lucide-react";

interface AddSongToPlaylistDialogProps {
  isOpen: boolean;
  onClose: () => void;
  playlistId: string;
}

export const AddSongToPlaylistDialog: React.FC<
  AddSongToPlaylistDialogProps
> = ({ isOpen, onClose, playlistId }) => {
  const {
    addSongToPlaylist,
    loading: playlistLoading,
    currentPlaylist,
  } = usePlaylistStore();
  const { allSongs, fetchAllSongs, loading: songsLoading } = useMusicStore(); // Assume you have a fetchAllSongs in useMusicStore
  const { toast } = useToast();

  const [searchTerm, setSearchTerm] = useState("");
  const [selectedSongId, setSelectedSongId] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      fetchAllSongs(); // Fetch all songs when dialog opens
      setSearchTerm("");
      setSelectedSongId(null);
    }
  }, [isOpen, fetchAllSongs]);

  const filteredSongs = allSongs.filter(
    (song) =>
      song.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      song.artist.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Filter out songs that are already in the current playlist
  const availableSongs = filteredSongs.filter(
    (song) => !currentPlaylist?.songs.some((s) => s._id === song._id)
  );

  const handleAddSong = async () => {
    if (selectedSongId) {
      const success = await addSongToPlaylist(playlistId, selectedSongId);
      if (success) {
        toast({ title: "Success", description: "Song added to playlist." });
        onClose();
      } else {
        toast({
          title: "Error",
          description: "Failed to add song to playlist.",
          variant: "destructive",
        });
      }
    } else {
      toast({
        title: "Error",
        description: "Please select a song.",
        variant: "destructive",
      });
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[600px] max-h-[80vh] flex flex-col">
        <DialogHeader>
          <DialogTitle>Add Song to Playlist</DialogTitle>
          <DialogDescription>
            Search for songs and add them to your playlist.
          </DialogDescription>
        </DialogHeader>
        <div className="py-4 flex-grow flex flex-col">
          <Input
            placeholder="Search songs by title or artist..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="mb-4"
          />
          <ScrollArea className="flex-grow pr-4">
            {songsLoading ? (
              <div className="text-center text-zinc-400">Loading songs...</div>
            ) : availableSongs.length === 0 ? (
              <div className="text-center text-zinc-400">
                No songs found or all songs are already in this playlist.
              </div>
            ) : (
              <div className="space-y-2">
                {availableSongs.map((song) => (
                  <div
                    key={song._id}
                    className={`flex items-center gap-3 p-2 rounded-md cursor-pointer transition-colors ${
                      selectedSongId === song._id
                        ? "bg-zinc-700 text-white"
                        : "hover:bg-zinc-800 text-zinc-300"
                    }`}
                    onClick={() =>
                      setSelectedSongId(
                        song._id === selectedSongId ? null : song._id
                      )
                    }
                  >
                    <img
                      src={song.imageUrl}
                      alt={song.title}
                      className="h-10 w-10 object-cover rounded"
                    />
                    <div className="flex-grow">
                      <div className="font-medium text-white">{song.title}</div>
                      <div className="text-sm text-zinc-400">{song.artist}</div>
                    </div>
                    {selectedSongId === song._id && (
                      <Check className="h-5 w-5 text-green-500" />
                    )}
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </div>
        <DialogFooter>
          <Button type="button" variant="secondary" onClick={onClose}>
            Cancel
          </Button>
          <Button
            onClick={handleAddSong}
            disabled={!selectedSongId || playlistLoading}
          >
            {playlistLoading ? "Adding..." : "Add Song"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
