// frontend/src/pages/LibraryPage/LibraryPage.tsx
import React, { useEffect } from "react";
import { ScrollArea } from "../../components/ui/scroll-area";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "../../components/ui/tabs";
import useLibraryStore from "../../stores/useLibraryStore";
import useMusicStore from "../../stores/useMusicStore";
import usePlaylistStore from "../../stores/usePlaylistStore"; // Import playlist store
import { Song } from "../../types"; // Assuming Song type is here
import { Album } from "../../types"; // Assuming Album type is here
import { Card, CardContent } from "../../components/ui/card"; // Assuming you use Card for display
import { Link } from "react-router-dom";
import { Play } from "lucide-react";
import usePlayerStore from "../../stores/usePlayerStore"; // Assuming player store

export const LibraryPage: React.FC = () => {
  const { likedSongs, fetchLikedSongs } = useLibraryStore();
  const { fetchFeaturedAlbums, featuredAlbums } = useMusicStore(); // Assuming you fetch albums here
  const { myPlaylists, fetchMyPlaylists } = usePlaylistStore(); // Get playlists and fetch function
  const { setCurrentSong, setIsPlaying, setQueue } = usePlayerStore();

  useEffect(() => {
    fetchLikedSongs();
    fetchFeaturedAlbums();
    fetchMyPlaylists(); // Fetch playlists when library loads
  }, [fetchLikedSongs, fetchFeaturedAlbums, fetchMyPlaylists]);

  const handlePlaySong = (song: Song) => {
    setCurrentSong(song);
    setIsPlaying(true);
    setQueue([song]); // Play only this song
  };

  const handlePlayAlbum = (album: Album) => {
    if (album.songs && album.songs.length > 0) {
      setQueue(album.songs);
      setCurrentSong(album.songs[0]);
      setIsPlaying(true);
    }
  };

  const handlePlayPlaylist = (playlist: Playlist) => {
    if (playlist.songs && playlist.songs.length > 0) {
      setQueue(playlist.songs);
      setCurrentSong(playlist.songs[0]);
      setIsPlaying(true);
    }
  };

  return (
    <ScrollArea className="h-full">
      <div className="p-8 pb-24">
        <h1 className="text-3xl font-bold mb-6 text-white">Your Library</h1>

        <Tabs defaultValue="playlists" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-zinc-800 text-white">
            {" "}
            {/* Adjusted grid-cols */}
            <TabsTrigger
              value="playlists"
              className="data-[state=active]:bg-zinc-700 data-[state=active]:text-white"
            >
              Playlists
            </TabsTrigger>
            <TabsTrigger
              value="albums"
              className="data-[state=active]:bg-zinc-700 data-[state=active]:text-white"
            >
              Albums
            </TabsTrigger>
            <TabsTrigger
              value="songs"
              className="data-[state=active]:bg-zinc-700 data-[state=active]:text-white"
            >
              Songs
            </TabsTrigger>
          </TabsList>

          <TabsContent value="playlists" className="mt-6">
            <h2 className="text-2xl font-semibold mb-4 text-white">
              Your Playlists
            </h2>
            {myPlaylists.length === 0 ? (
              <p className="text-zinc-400">
                You haven't created any playlists yet.
              </p>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6">
                {myPlaylists
                  .sort(
                    (a, b) =>
                      new Date(b.createdAt).getTime() -
                      new Date(a.createdAt).getTime()
                  )
                  .map((playlist) => (
                    <Card
                      key={playlist._id}
                      className="relative group bg-zinc-900 border-zinc-800 text-white rounded-lg overflow-hidden transition-all hover:bg-zinc-800 hover:scale-[1.02]"
                    >
                      <Link to={`/playlist/${playlist._id}`} className="block">
                        <CardContent className="p-4 flex flex-col items-center">
                          <img
                            src={
                              playlist.imageUrl || "/default-playlist-cover.png"
                            }
                            alt={playlist.title}
                            className="w-full h-auto aspect-square object-cover rounded-md mb-3 shadow-md"
                          />
                          <h3 className="text-md font-semibold text-center truncate w-full">
                            {playlist.title}
                          </h3>
                          <p className="text-sm text-zinc-400 text-center truncate w-full">
                            {playlist.isPublic
                              ? "Public Playlist"
                              : "Private Playlist"}
                          </p>
                        </CardContent>
                      </Link>
                      <div className="absolute bottom-16 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <Button
                          size="icon"
                          className="rounded-full bg-green-500 hover:bg-green-600 text-black shadow-lg"
                          onClick={() => handlePlayPlaylist(playlist)}
                        >
                          <Play className="h-5 w-5 fill-black" />
                        </Button>
                      </div>
                    </Card>
                  ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="albums" className="mt-6">
            <h2 className="text-2xl font-semibold mb-4 text-white">
              Your Albums
            </h2>
            {featuredAlbums.length === 0 ? (
              <p className="text-zinc-400">No albums in your library.</p>
            ) : (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6">
                {featuredAlbums.map((album) => (
                  <Card
                    key={album._id}
                    className="relative group bg-zinc-900 border-zinc-800 text-white rounded-lg overflow-hidden transition-all hover:bg-zinc-800 hover:scale-[1.02]"
                  >
                    <Link to={`/album/${album._id}`} className="block">
                      <CardContent className="p-4 flex flex-col items-center">
                        <img
                          src={album.imageUrl}
                          alt={album.title}
                          className="w-full h-auto aspect-square object-cover rounded-md mb-3 shadow-md"
                        />
                        <h3 className="text-md font-semibold text-center truncate w-full">
                          {album.title}
                        </h3>
                        <p className="text-sm text-zinc-400 text-center truncate w-full">
                          {album.artist}
                        </p>
                      </CardContent>
                    </Link>
                    <div className="absolute bottom-16 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                      <Button
                        size="icon"
                        className="rounded-full bg-green-500 hover:bg-green-600 text-black shadow-lg"
                        onClick={() => handlePlayAlbum(album)}
                      >
                        <Play className="h-5 w-5 fill-black" />
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="songs" className="mt-6">
            <h2 className="text-2xl font-semibold mb-4 text-white">
              Liked Songs
            </h2>
            {likedSongs.length === 0 ? (
              <p className="text-zinc-400">You haven't liked any songs yet.</p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
                {likedSongs.map((song) => (
                  <Card
                    key={song._id}
                    className="flex items-center bg-zinc-900 border-zinc-800 text-white rounded-lg p-2 transition-all hover:bg-zinc-800"
                  >
                    <img
                      src={song.imageUrl}
                      alt={song.title}
                      className="w-16 h-16 object-cover rounded mr-4"
                    />
                    <div className="flex-grow">
                      <h3 className="text-md font-semibold truncate">
                        {song.title}
                      </h3>
                      <p className="text-sm text-zinc-400 truncate">
                        {song.artist}
                      </p>
                    </div>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="ml-auto text-green-500 hover:text-green-400"
                      onClick={() => handlePlaySong(song)}
                    >
                      <Play className="h-5 w-5" />
                    </Button>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </ScrollArea>
  );
};
