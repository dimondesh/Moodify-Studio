// frontend/src/layout/LeftSidebar.tsx
import { Link, useLocation } from "react-router-dom";
import { cn } from "../lib/utils";
import {
  Home,
  Search,
  Library,
  Plus,
  ArrowRight,
  User,
  Github,
  MessageSquare,
  BarChart,
  Crown,
  Heart,
  Music,
  ListMusic, // Import for playlists
} from "lucide-react";
import { Button } from "../components/ui/button";
import { ScrollArea } from "../components/ui/scroll-area";
import { useAuthStore } from "../stores/useAuthStore";
import useMusicStore from "../stores/useMusicStore";
import useLibraryStore from "../stores/useLibraryStore";
import usePlaylistStore from "../stores/usePlaylistStore"; // Import playlist store
import { useEffect, useState } from "react";
import { CreatePlaylistDialog } from "../pages/Playlists/CreatePlaylistDialog"; // Import the dialog

export const LeftSidebar = () => {
  const { user } = useAuthStore();
  const { fetchFeaturedAlbums, featuredAlbums } = useMusicStore();
  const { likedSongs, fetchLikedSongs } = useLibraryStore();
  const { myPlaylists, fetchMyPlaylists } = usePlaylistStore(); // Get myPlaylists and fetch function

  const location = useLocation();
  const [isCreatePlaylistDialogOpen, setIsCreatePlaylistDialogOpen] =
    useState(false); // State for dialog

  useEffect(() => {
    fetchFeaturedAlbums();
    if (user) {
      fetchLikedSongs();
      fetchMyPlaylists(); // Fetch user's playlists
    }
  }, [fetchFeaturedAlbums, fetchLikedSongs, fetchMyPlaylists, user]);

  const navItems = [
    { name: "Home", icon: Home, href: "/" },
    { name: "Search", icon: Search, href: "/search" },
  ];

  const libraryItems = [
    { name: "Your Library", icon: Library, href: "/library" },
    {
      name: "Liked Songs",
      icon: Heart,
      href: "/collection/tracks",
      image: "/liked.png",
    },
  ];

  const adminItems = [
    { name: "Admin Panel", icon: Crown, href: "/admin" },
    { name: "Stats", icon: BarChart, href: "/admin/stats" },
  ];

  const bottomNavItems = [
    { name: "Profile", icon: User, href: "/profile" },
    { name: "Chat", icon: MessageSquare, href: "/chat" },
    {
      name: "Github",
      icon: Github,
      href: "https://github.com/dimondesh/Moodify",
      external: true,
    },
  ];

  return (
    <div className="hidden lg:flex flex-col h-full bg-black text-white p-4 space-y-4">
      {/* Navigation */}
      <nav className="bg-zinc-900 rounded-lg p-4 space-y-2">
        {navItems.map((item) => (
          <Link
            key={item.name}
            to={item.href}
            className={cn(
              "flex items-center gap-4 p-2 rounded-md transition-colors hover:bg-zinc-800",
              location.pathname === item.href
                ? "bg-zinc-800 text-white"
                : "text-zinc-400"
            )}
          >
            <item.icon className="h-6 w-6" />
            <span className="text-lg font-semibold">{item.name}</span>
          </Link>
        ))}
      </nav>

      {/* Library */}
      <div className="bg-zinc-900 rounded-lg p-4 flex-grow flex flex-col">
        <div className="flex items-center justify-between mb-4">
          <Link
            to="/library"
            className={cn(
              "flex items-center gap-4 p-2 rounded-md transition-colors hover:bg-zinc-800",
              location.pathname === "/library"
                ? "bg-zinc-800 text-white"
                : "text-zinc-400"
            )}
          >
            <Library className="h-6 w-6" />
            <span className="text-lg font-semibold">Your Library</span>
          </Link>
          <Button
            variant="ghost"
            size="icon"
            className="text-zinc-400 hover:text-white"
            onClick={() => setIsCreatePlaylistDialogOpen(true)} // Open playlist creation dialog
          >
            <Plus className="h-5 w-5" />
          </Button>
        </div>
        <ScrollArea className="flex-grow pr-2">
          <div className="space-y-2">
            {libraryItems.map((item) => (
              <Link
                key={item.name}
                to={item.href}
                className={cn(
                  "flex items-center gap-4 p-2 rounded-md transition-colors hover:bg-zinc-800",
                  location.pathname === item.href
                    ? "bg-zinc-800 text-white"
                    : "text-zinc-400"
                )}
              >
                {item.image ? (
                  <img
                    src={item.image}
                    alt={item.name}
                    className="h-6 w-6 rounded"
                  />
                ) : (
                  <item.icon className="h-6 w-6" />
                )}
                <span className="text-md font-medium">{item.name}</span>
              </Link>
            ))}

            {/* Render User's Playlists */}
            {myPlaylists.length > 0 && (
              <>
                <div className="mt-4 pt-2 border-t border-zinc-700">
                  <h3 className="text-sm font-semibold text-zinc-400 mb-2">
                    Your Playlists
                  </h3>
                </div>
                {myPlaylists
                  .sort(
                    (a, b) =>
                      new Date(b.createdAt).getTime() -
                      new Date(a.createdAt).getTime()
                  ) // Sort by creation date
                  .map((playlist) => (
                    <Link
                      key={playlist._id}
                      to={`/playlist/${playlist._id}`}
                      className={cn(
                        "flex items-center gap-4 p-2 rounded-md transition-colors hover:bg-zinc-800",
                        location.pathname === `/playlist/${playlist._id}`
                          ? "bg-zinc-800 text-white"
                          : "text-zinc-400"
                      )}
                    >
                      <img
                        src={playlist.imageUrl || "/default-playlist-cover.png"}
                        alt={playlist.title}
                        className="h-6 w-6 rounded object-cover"
                      />
                      <span className="text-md font-medium truncate">
                        {playlist.title}
                      </span>
                      {playlist.isPublic ? (
                        <span className="ml-auto text-xs text-green-500">
                          Public
                        </span>
                      ) : (
                        <span className="ml-auto text-xs text-zinc-500">
                          Private
                        </span>
                      )}
                    </Link>
                  ))}
              </>
            )}

            {/* Featured Albums (optional, keep existing if needed) */}
            {/*
            {featuredAlbums.length > 0 && (
              <>
                <div className="mt-4 pt-2 border-t border-zinc-700">
                  <h3 className="text-sm font-semibold text-zinc-400 mb-2">Featured Albums</h3>
                </div>
                {featuredAlbums.map((album) => (
                  <Link
                    key={album._id}
                    to={`/album/${album._id}`}
                    className={cn(
                      'flex items-center gap-4 p-2 rounded-md transition-colors hover:bg-zinc-800',
                      location.pathname === `/album/${album._id}` ? 'bg-zinc-800 text-white' : 'text-zinc-400'
                    )}
                  >
                    <img src={album.imageUrl} alt={album.title} className="h-6 w-6 rounded" />
                    <span className="text-md font-medium truncate">{album.title}</span>
                  </Link>
                ))}
              </>
            )}
            */}
          </div>
        </ScrollArea>
      </div>

      {/* Admin Panel (if user is admin) */}
      {user?.isAdmin && (
        <nav className="bg-zinc-900 rounded-lg p-4 space-y-2">
          {adminItems.map((item) => (
            <Link
              key={item.name}
              to={item.href}
              className={cn(
                "flex items-center gap-4 p-2 rounded-md transition-colors hover:bg-zinc-800",
                location.pathname.startsWith(item.href)
                  ? "bg-zinc-800 text-white"
                  : "text-zinc-400"
              )}
            >
              <item.icon className="h-6 w-6" />
              <span className="text-lg font-semibold">{item.name}</span>
            </Link>
          ))}
        </nav>
      )}

      {/* Bottom Navigation */}
      <nav className="bg-zinc-900 rounded-lg p-4 space-y-2">
        {bottomNavItems.map((item) =>
          item.external ? (
            <a
              key={item.name}
              href={item.href}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-4 p-2 rounded-md transition-colors text-zinc-400 hover:bg-zinc-800 hover:text-white"
            >
              <item.icon className="h-6 w-6" />
              <span className="text-lg font-semibold">{item.name}</span>
              <ArrowRight className="ml-auto h-4 w-4" />
            </a>
          ) : (
            <Link
              key={item.name}
              to={item.href}
              className={cn(
                "flex items-center gap-4 p-2 rounded-md transition-colors hover:bg-zinc-800",
                location.pathname === item.href
                  ? "bg-zinc-800 text-white"
                  : "text-zinc-400"
              )}
            >
              <item.icon className="h-6 w-6" />
              <span className="text-lg font-semibold">{item.name}</span>
            </Link>
          )
        )}
      </nav>

      <CreatePlaylistDialog
        isOpen={isCreatePlaylistDialogOpen}
        onClose={() => setIsCreatePlaylistDialogOpen(false)}
      />
    </div>
  );
};
