/* eslint-disable @typescript-eslint/no-explicit-any */
// frontend/src/stores/usePlaylistStore.ts
import { create } from "zustand";
import { axiosInstance } from "../lib/axios";
import { Playlist, Song } from "../types";

interface PlaylistState {
  myPlaylists: Playlist[];
  publicPlaylists: Playlist[];
  currentPlaylist: Playlist | null;
  loading: boolean;
  error: string | null;
  fetchMyPlaylists: () => Promise<void>;
  fetchPublicPlaylists: () => Promise<void>;
  fetchPlaylistById: (id: string) => Promise<void>;
  createPlaylist: (
    title: string,
    description: string,
    isPublic: boolean,
    imageFile?: File
  ) => Promise<Playlist | null>;
  updatePlaylist: (
    id: string,
    title?: string,
    description?: string,
    isPublic?: boolean,
    imageFile?: File
  ) => Promise<Playlist | null>;
  deletePlaylist: (id: string) => Promise<boolean>;
  addSongToPlaylist: (playlistId: string, songId: string) => Promise<boolean>;
  removeSongFromPlaylist: (
    playlistId: string,
    songId: string
  ) => Promise<boolean>;
  likePlaylist: (playlistId: string) => Promise<boolean>;
  unlikePlaylist: (playlistId: string) => Promise<boolean>;
  clearCurrentPlaylist: () => void;
}

const usePlaylistStore = create<PlaylistState>((set) => ({
  myPlaylists: [],
  publicPlaylists: [],
  currentPlaylist: null,
  loading: false,
  error: null,

  fetchMyPlaylists: async () => {
    set({ loading: true, error: null });
    try {
      const response = await axiosInstance.get("/api/playlists/my");
      set({ myPlaylists: response.data, loading: false });
    } catch (err: any) {
      console.error("Failed to fetch my playlists:", err);
      set({
        error: err.response?.data?.message || "Failed to fetch my playlists",
        loading: false,
      });
    }
  },

  fetchPublicPlaylists: async () => {
    set({ loading: true, error: null });
    try {
      const response = await axiosInstance.get("/api/playlists/public");
      set({ publicPlaylists: response.data, loading: false });
    } catch (err: any) {
      console.error("Failed to fetch public playlists:", err);
      set({
        error:
          err.response?.data?.message || "Failed to fetch public playlists",
        loading: false,
      });
    }
  },

  fetchPlaylistById: async (id: string) => {
    set({ loading: true, error: null, currentPlaylist: null });
    try {
      const response = await axiosInstance.get(`/api/playlists/${id}`);
      set({ currentPlaylist: response.data, loading: false });
    } catch (err: any) {
      console.error(`Failed to fetch playlist with ID ${id}:`, err);
      set({
        error: err.response?.data?.message || `Failed to fetch playlist ${id}`,
        loading: false,
      });
      return null;
    }
  },

  createPlaylist: async (title, description, isPublic, imageFile) => {
    set({ loading: true, error: null });
    try {
      const formData = new FormData();
      formData.append("title", title);
      formData.append("description", description);
      formData.append("isPublic", String(isPublic));
      if (imageFile) {
        formData.append("imageFile", imageFile);
      }

      const response = await axiosInstance.post("/api/playlists", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      set((state) => ({
        myPlaylists: [...state.myPlaylists, response.data],
        loading: false,
      }));
      return response.data;
    } catch (err: any) {
      console.error("Failed to create playlist:", err);
      set({
        error: err.response?.data?.message || "Failed to create playlist",
        loading: false,
      });
      return null;
    }
  },

  updatePlaylist: async (id, title, description, isPublic, imageFile) => {
    set({ loading: true, error: null });
    try {
      const formData = new FormData();
      if (title !== undefined) formData.append("title", title);
      if (description !== undefined)
        formData.append("description", description);
      if (isPublic !== undefined) formData.append("isPublic", String(isPublic));
      if (imageFile) formData.append("imageFile", imageFile);

      const response = await axiosInstance.put(
        `/api/playlists/${id}`,
        formData,
        {
          headers: { "Content-Type": "multipart/form-data" },
        }
      );
      set((state) => ({
        myPlaylists: state.myPlaylists.map((p) =>
          p._id === id ? response.data : p
        ),
        currentPlaylist:
          state.currentPlaylist?._id === id
            ? response.data
            : state.currentPlaylist,
        loading: false,
      }));
      return response.data;
    } catch (err: any) {
      console.error("Failed to update playlist:", err);
      set({
        error: err.response?.data?.message || "Failed to update playlist",
        loading: false,
      });
      return null;
    }
  },

  deletePlaylist: async (id) => {
    set({ loading: true, error: null });
    try {
      await axiosInstance.delete(`/api/playlists/${id}`);
      set((state) => ({
        myPlaylists: state.myPlaylists.filter((p) => p._id !== id),
        loading: false,
      }));
      return true;
    } catch (err: any) {
      console.error("Failed to delete playlist:", err);
      set({
        error: err.response?.data?.message || "Failed to delete playlist",
        loading: false,
      });
      return false;
    }
  },

  addSongToPlaylist: async (playlistId, songId) => {
    set({ loading: true, error: null });
    try {
      const response = await axiosInstance.post(
        `/api/playlists/${playlistId}/songs`,
        { songId }
      );
      set((state) => ({
        currentPlaylist:
          state.currentPlaylist?._id === playlistId
            ? response.data.playlist
            : state.currentPlaylist,
        myPlaylists: state.myPlaylists.map((p) =>
          p._id === playlistId ? response.data.playlist : p
        ),
        loading: false,
      }));
      return true;
    } catch (err: any) {
      console.error("Failed to add song to playlist:", err);
      set({
        error: err.response?.data?.message || "Failed to add song to playlist",
        loading: false,
      });
      return false;
    }
  },

  removeSongFromPlaylist: async (playlistId, songId) => {
    set({ loading: true, error: null });
    try {
      const response = await axiosInstance.delete(
        `/api/playlists/${playlistId}/songs/${songId}`
      );
      set((state) => ({
        currentPlaylist:
          state.currentPlaylist?._id === playlistId
            ? response.data.playlist
            : state.currentPlaylist,
        myPlaylists: state.myPlaylists.map((p) =>
          p._id === playlistId ? response.data.playlist : p
        ),
        loading: false,
      }));
      return true;
    } catch (err: any) {
      console.error("Failed to remove song from playlist:", err);
      set({
        error:
          err.response?.data?.message || "Failed to remove song from playlist",
        loading: false,
      });
      return false;
    }
  },

  likePlaylist: async (playlistId) => {
    set({ loading: true, error: null });
    try {
      const response = await axiosInstance.post(
        `/api/playlists/${playlistId}/like`
      );
      set((state) => ({
        currentPlaylist:
          state.currentPlaylist?._id === playlistId
            ? response.data.playlist
            : state.currentPlaylist,
        myPlaylists: state.myPlaylists.map((p) =>
          p._id === playlistId ? response.data.playlist : p
        ),
        publicPlaylists: state.publicPlaylists.map((p) =>
          p._id === playlistId ? response.data.playlist : p
        ),
        loading: false,
      }));
      return true;
    } catch (err: any) {
      console.error("Failed to like playlist:", err);
      set({
        error: err.response?.data?.message || "Failed to like playlist",
        loading: false,
      });
      return false;
    }
  },

  unlikePlaylist: async (playlistId) => {
    set({ loading: true, error: null });
    try {
      const response = await axiosInstance.delete(
        `/api/playlists/${playlistId}/unlike`
      );
      set((state) => ({
        currentPlaylist:
          state.currentPlaylist?._id === playlistId
            ? response.data.playlist
            : state.currentPlaylist,
        myPlaylists: state.myPlaylists.map((p) =>
          p._id === playlistId ? response.data.playlist : p
        ),
        publicPlaylists: state.publicPlaylists.map((p) =>
          p._id === playlistId ? response.data.playlist : p
        ),
        loading: false,
      }));
      return true;
    } catch (err: any) {
      console.error("Failed to unlike playlist:", err);
      set({
        error: err.response?.data?.message || "Failed to unlike playlist",
        loading: false,
      });
      return false;
    }
  },

  clearCurrentPlaylist: () => set({ currentPlaylist: null }),
}));

export default usePlaylistStore;
